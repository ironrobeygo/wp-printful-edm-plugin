(function () {
  const container = document.getElementById("pfc-inline-filters");

  function collectFilters() {
    const pick = (name) =>
      Array.from(
        container.querySelectorAll(`input[name="${name}[]"]:checked`)
      ).map((i) => i.value);

    return {
      technique: pick("technique"),
      color: pick("color"),
      branding_options: pick("branding_options"),
      sizes: pick("sizes"),
      material: pick("material"),
      models: pick("models"),
      flags: pick("flags"),
    };
  }

  // Whenever a checkbox changes, refresh the grid (reset paging)
  container?.addEventListener("change", (e) => {
    if (e.target.matches('input[type="checkbox"]')) {
      window.pfCatalogFilters = collectFilters();
      if (typeof window.pfReloadCatalog === "function") {
        window.pfReloadCatalog(/* reset = */ true);
      }
    }
  });

  // "Clear" links per group
  container?.querySelectorAll("[data-clear]").forEach((a) => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      const group = a.getAttribute("data-clear");
      container
        .querySelectorAll(`input[name="${group}[]"]`)
        .forEach((i) => (i.checked = false));
      window.pfCatalogFilters = collectFilters();
      if (typeof window.pfReloadCatalog === "function") {
        window.pfReloadCatalog(true);
      }
    });
  });

  // expose current filters for your loader
  window.pfCatalogFilters = collectFilters();

  // Example: patch your existing loader to include filters
  // If you already do this, ignore.
  if (!window.pfFetchPagePatched) {
    window.pfFetchPagePatched = true;
    const orig = window.pfFetchPage;
    window.pfFetchPage = async function (reset = false) {
      // make sure your AJAX request body includes:
      //   filters: window.pfCatalogFilters
      return orig ? orig(reset) : null;
    };
  }
})();

(function(){
	const grid     = document.getElementById('pfc-grid');
	const loadBt   = document.getElementById('pfc-load-more');
	const meta     = document.getElementById('pfc-results-meta');
	const searchEl = document.getElementById('pfc-search');
	const topbar   = document.querySelector('.pfc-topbar');
  
	const state = {
	  offset: 0,
	  limit: 24,
	  hasMore: false,
	  nextOffset: null,
	  filters: window.pfCatalogFilters || {},
	  sort: 'popular',
	  q: ''
	};
  
	// Debounce helper
	const debounce = (fn, ms=300) => { let t; return (...a)=>{clearTimeout(t); t=setTimeout(()=>fn(...a),ms)}; };
  
	function collectFiltersFromDOM() {
	  const root = document;
	  const pick = (name) => Array.from(root.querySelectorAll(`input[name="${name}[]"]:checked`)).map(i=>i.value);
	  return {
		technique:        pick('technique'),
		color:            pick('color'),
		branding_options: pick('branding_options'),
		sizes:            pick('sizes'),
		material:         pick('material'),
		models:           pick('models'),
		flags:            pick('flags'),
	  };
	}
  
	function setResultsMeta(total) {
	  meta.textContent = typeof total === 'number' ? `Showing ${total} results` : '';
	}
  
	function productCard(p){
	  const price = p.min_price ? `From ${p.min_price}` : '';
	  const img   = p.thumbnail_url ? `<img src="${p.thumbnail_url}" alt="">` : '';
	  return `
		<article class="pfc-card">
		  <div class="pfc-thumb">${img}</div>
		  <div class="pfc-title"><strong>${p.name || ''}</strong></div>
		  ${price ? `<div class="pfc-price">${price}</div>` : ``}
		  <div class="pfc-actions"><a href="${p.url || '#'}" class="pfc-btn">Design product</a></div>
		</article>
	  `;
	}
  
	function render(items, reset=false){
	  if (reset) grid.innerHTML = '';
	  if (!items || !items.length){
		if (reset) grid.innerHTML = `<div style="padding:20px;color:#666;">No products match your filters.</div>`;
		return;
	  }
	  grid.insertAdjacentHTML('beforeend', items.map(productCard).join(''));
	}
  
	async function fetchPage(reset=false){
	  if (reset) { state.offset = 0; state.nextOffset = null; grid.innerHTML = ''; }
	  const payload = {
		action: 'pf_get_products',
		nonce: '<?php echo esc_js($nonce); ?>',
		offset: state.offset,
		limit: state.limit,
		filters: state.filters,
		sort: state.sort,
		q: state.q
		// optionally include category if you scope (e.g., 'mens_all')
		// category_id: 'mens_all'
	  };
	  loadBt.disabled = true;
	  const res = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
		method: 'POST',
		headers: {'Content-Type':'application/json'},
		body: JSON.stringify(payload)
	  }).then(r=>r.json()).catch(()=>({success:false}));
  
	  if (!res?.success){ render([], true); setResultsMeta(0); loadBt.style.display='none'; return; }
  
	  const { items, hasMore, nextOffset, total } = res.data || {};
	  render(items || [], reset);
	  setResultsMeta(total);
	  state.hasMore   = !!hasMore;
	  state.nextOffset= nextOffset;
	  state.offset    = nextOffset ?? (state.offset + (items?.length || 0));
	  loadBt.style.display = state.hasMore ? 'inline-block' : 'none';
	  loadBt.disabled = false;
	}
  
	// Expose reloader for other scripts if needed
	window.pfReloadCatalog = function(reset=true){
	  state.filters = collectFiltersFromDOM();
	  return fetchPage(!!reset);
	}
  
	// Sort handler
	topbar?.addEventListener('change', (e)=>{
	  if (e.target.name === 'sort'){
		state.sort = e.target.value;
		fetchPage(true);
	  }
	});
  
	// Filter change
	document.addEventListener('change', (e)=>{
	  if (e.target.matches('input[type="checkbox"][name$="[]"]')){
		fetchPage(true);
	  }
	});
  
	// Clear links
	document.querySelectorAll('[data-clear]').forEach(a=>{
	  a.addEventListener('click', (e)=>{
		e.preventDefault();
		const group = a.getAttribute('data-clear');
		document.querySelectorAll(`input[name="${group}[]"]`).forEach(i=> i.checked=false);
		fetchPage(true);
	  });
	});
  
	// Search (debounced)
	const onSearch = debounce(()=>{
	  state.q = (searchEl.value || '').trim();
	  fetchPage(true);
	}, 350);
	searchEl?.addEventListener('input', onSearch);
  
	// Load more
	loadBt?.addEventListener('click', ()=> fetchPage(false));
  
	// Initial
	state.filters = collectFiltersFromDOM();
	fetchPage(true);
  })();